<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       http://www.ParmisIT.com
 * @since      1.0.0
 *
 * @package    Parmis_Shop
 * @subpackage Parmis_Shop/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Parmis_Shop
 * @subpackage Parmis_Shop/public
 * @author     Hassan Azizi <azizi55@ymail.com>
 * @author     kian babai <kian.babai.09@gmail.com>
 */
class Parmis_Shop_Public
{

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;
	private  static $serverAddress = "http://localhost:3428/";
	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;
	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */

	public function __construct($plugin_name, $version)
	{
		$this->plugin_name = $plugin_name;
		$this->version = $version;
	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles()
	{

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Parmis_Shop_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Parmis_Shop_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/parmis-shop-public.css', array(), $this->version, 'all');
	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts()
	{

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Parmis_Shop_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Parmis_Shop_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/parmis-shop-public.js', array('jquery'), $this->version, true);
		wp_localize_script($this->plugin_name, 'parmis_shop_object', [
			'url'	=>	admin_url('admin-ajax.php'),
			'nonce'	=>	wp_create_nonce('parmis_shop_object_nonce')
		]);
	}

	function str_contains2(string $haystack, string $needle): bool
	{
		return '' === $needle || false !== strpos($haystack, $needle);
	}

	//start of update parts
	public static function sync_parts()
	{
		try {
			global $wpdb;
			global $table_prefix;
			$productIds = array();

			$products = $wpdb->get_results("SELECT id FROM " . $table_prefix . "posts WHERE post_status = 'publish' AND post_type IN ('product', 'product_variation') AND ID NOT IN ( SELECT ID FROM " . $table_prefix . "posts AS p1 WHERE post_status = 'publish' AND post_type ='product' AND (SELECT COUNT(*) FROM " . $table_prefix . "posts WHERE post_parent = p1.ID AND post_status = 'publish') > 0)");

			$skus = $wpdb->get_results("SELECT pm.meta_value,pm.post_id FROM " . $table_prefix . "postmeta As pm Where pm.meta_key='_sku';");
			foreach ($products as $product) {
				$key = array_search($product->id, array_column($skus, "post_id"));

				if ($key === false)
					$productIds[] = $product->id;
				else
					$productIds[] = $skus[$key]->meta_value;
			}

			$parts = self::call_post("WebShopThirdParty/GetPartsByCodes", $productIds);

			foreach ($parts as $part) {
				self::update_part_record($part, $skus);
			}

			return 'بروزرسانی کالاها با موفقیت انجام شد';
		} catch (Exception $e) {
			return $e->getMessage();
			self::parmis_shop_loader()->parmis_error_log(basename(__FILE__), __LINE__, $e->getMessage());
		}
	}

	public static function update_parts($cart)
	{
		$setting = self::get_settings();
		try {
			global $wpdb;
			global $table_prefix;
			$codes = array();
			foreach ($cart as $cart_item_key => $values) {
				$product = $values['data'];
				$codes[] = $product->id;
			}

			self::update_parts_info($codes);
		} catch (Exception $e) {
			if ($setting->parmis_shop_debug_mode) {
				echo ('<h4 dir="ltr">update_parts<br>' . 'Exception: ' . $e->getMessage() . '</h4>');
				self::parmis_shop_loader()->parmis_error_log(basename(__FILE__), __LINE__, 'Exception: ' . $e->getMessage());
			}
		}
	}

	private function update_parts_info($codes)
	{
		global $wpdb;
		global $table_prefix;

		$skus = $wpdb->get_results("SELECT pm.meta_value,pm.post_id FROM " . $table_prefix . "postmeta As pm Where pm.meta_key='_sku';");
		$parts = self::call_post("WebShopThirdParty/GetPartsByCodes", $codes);
		if (!empty($parts))
			foreach ($parts as $part) {
				self::update_part_record($part, $skus);
			}
	}

	public static function update_part_record($part, $skus)
	{
		global $wpdb;
		global $table_prefix;
		$setting = self::get_settings();
		$postID = 0;

		$key = array_search($part->summaryCode, array_column($skus, "meta_value"));

		if ($key === false)
			$postID = $part->summaryCode;
		else
			$postID = $skus[$key]->post_id;

		if ($setting->parmis_shop_debug_mode) {
			var_dump($part);
			echo  $postID;
			self::parmis_shop_loader()->parmis_error_log(basename(__FILE__), __LINE__, serialize($part));
		}

		if ($setting->parmis_shop_update_quantities) {
			$wpdb->update(
				$table_prefix . 'postmeta',
				array(
					'meta_value'     => $part->saleableQuantity,
				),
				array(
					'post_id'     => $postID,
					'meta_key'     => '_stock'
				)
			);

			if ($part->saleableQuantity > 0) {
				$wpdb->update(
					$table_prefix . 'postmeta',
					array(
						'meta_value'     => 'instock',
					),
					array(
						'post_id'     => $postID,
						'meta_key'     => '_stock_status'
					)
				);
			} else {
				$wpdb->update(
					$table_prefix . 'postmeta',
					array(
						'meta_value'     => 'outofstock',
					),
					array(
						'post_id'     => $postID,
						'meta_key'     => '_stock_status'
					)
				);
			}
		}

		if ($setting->parmis_shop_update_prices) {
			$price = $part->price;
			if ($setting->parmis_shop_is_toman)
				$price = $price / 10;

			update_post_meta($postID, '_regular_price', $price);
			$sale_price = get_post_meta($postID, '_sale_price', true);
			if (!empty($sale_price) && $sale_price > 0) {
				update_post_meta($postID, '_price', $sale_price);
			} else {
				update_post_meta($postID, '_price', $price);
			}
			//wc update hook was implemented after price update to be detectable
			do_action('woocommerce_update_product', $postID);
		}
	}

	private function get_part_code($skus, $productID)
	{
		$item = null;
		foreach ($skus as $struct) {
			if ($struct->post_id == $productID) {
				$item = $struct;
				break;
			}
		}
		return $item->meta_value;
	}

	private function get_post_id($skus, $summaryCode)
	{
		$item = null;
		foreach ($skus as $struct) {
			if ($struct->meta_value == $summaryCode) {
				$item = $struct;
				break;
			}
		}
		return $item->post_id;
	}

	private function part_exists($parts, $summaryCode)
	{
		foreach ($parts as $part) {
			if ($part->summaryCode == $summaryCode) {
				return true;
			}
		}
		return false;
	}
	////end of update parts

	//start of add order
	public static function add_order($order)
	{
		try {
			global $wpdb;
			global $table_prefix;

			$res = $wpdb->get_results("SELECT * FROM " . $table_prefix . "star_send_log WHERE order_id = " . $order->id);
			$setting = self::get_settings();

			if (!empty($res)) {
				if ($res[0]->is_sent) return;
			} else {
				$wpdb->insert(
					$table_prefix . 'star_send_log',
					array(
						'order_id'     			=> $order->id,
						'star_serial'    		=> '0',
						'is_sent'    			=> false,
						'fail_message' 			=> '',
						'fail_detail_message' 	=> '',
						'order_date'            => $order->order_date
					)
				);
			}

			// $starCustomerCode = self::save_or_get_customer_id($order, false);

			$countryCode = $order->get_billing_country();
			$stateCode = $order->get_billing_state();
			$stateName = WC()->countries->get_states($countryCode)[$stateCode];
			$cityName = $order->get_billing_city();

			$order_data = $order->get_data();
			$ShopingCartUserInputDTO = new stdClass();
			$ShopingCartUserInputDTO->Date = $order->order_date;
			$ShopingCartUserInputDTO->CustomerAlias = $order->data['billing']['first_name'] . ' ' . $order->data['billing']['last_name'];
			$ShopingCartUserInputDTO->Address = $stateName . '، ' . $cityName . '، ' . $order->get_billing_address_1() . '، ' . $order->get_billing_address_2() . '، ' . $order->get_billing_postcode();
			$ShopingCartUserInputDTO->Telephone = $order->data['billing']['phone'];
			$ShopingCartUserInputDTO->MobileNumber = $order->data['billing']['phone'];
			$ShopingCartUserInputDTO->CustomerCode = $starCustomerCode;
			$ShopingCartUserInputDTO->OrderNumber = $order->data['id'];

			$order_submission_type = get_option('parmis_order_type_submit');
			if (!empty($order_submission_type) && (int) $order_submission_type !== 1) {
				$val = NULL;
				switch ($order_submission_type) {
					case 2:
						$val = 'AF54EA95-3B9E-48FA-ADB0-4931EFA30209';
						break;
					case 3:
						$val = '0068920A-F122-44ED-B9CA-6EA12187355E';
						break;
					case 4:
						$val = '19D8F212-2376-4AA9-9A7A-BED7B2FA70FD';
						break;
					default:
						break;
				}
				$ShopingCartUserInputDTO->TransactionType = $val;
			}

			$ShopingCartUserInputDTO->Total = $order->data['total'];


			if ($setting->parmis_shop_is_toman)
				$ShopingCartUserInputDTO->Total = $ShopingCartUserInputDTO->Total * 10;

			$errors = array();

			$skus = $wpdb->get_results("SELECT pm.meta_value,pm.post_id FROM " . $table_prefix . "postmeta As pm Where pm.meta_key='_sku';");
			foreach ($order->data['line_items'] as $item) {
				$lineItem = $item->get_data();
				$partItem = new stdClass();
				$key = array_search($lineItem['product_id'], array_column($skus, "post_id"));


				if ($key === false) {
					if ($lineItem['variation_id'] != 0) {
						// $partItem->summaryCode = $lineItem['variation_id'];
						$var_product = wc_get_product($lineItem['variation_id']);
						$partItem->summaryCode = $var_product->get_sku();
						$partItem->Price = $var_product->get_price();
					} else {
						$partItem->summaryCode = $lineItem['product_id'];
						$product = wc_get_product($lineItem['product_id']);
						$partItem->Price = $product->get_price();
					}
					$partItem->Amount = $lineItem['quantity'];
				} else {
					$partItem->summaryCode = $skus[$key]->meta_value;
					$partItem->Amount = $lineItem['quantity'];
					$partItem->Price = $lineItem['total'] / $partItem->Amount;
				}

				if ($setting->parmis_shop_is_toman) {
					$partItem->Price = $partItem->Price * 10;
				}

				$ShopingCartUserInputDTO->items[] = $partItem;
			}

			if (!empty($errors)) {
				throw new Exception(implode('<br>', $errors));
			}

			if (empty($order_data['payment_method']) || $order_data['payment_method'] == "cod" || $order_data['payment_method'] == "cheque") {
				$ShopingCartUserInputDTO->HasPayment = false;
				$ShopingCartUserInputDTO->BankAccountCode = 0;
			} else {
				$bankAccountCode = self::get_bank_account_code($order_data['payment_method']);

				if ($bankAccountCode == 0) {
					$bankAccountCode_message = 'کد حساب بانکی استار برای روش پرداخت ' . $order_data['payment_method'] . ' تعریف نشده است';
					throw new Exception($bankAccountCode_message);
					self::parmis_shop_loader()->parmis_error_log(basename(__FILE__), __LINE__, $bankAccountCode_message);
				}

				$ShopingCartUserInputDTO->HasPayment = true;
				$ShopingCartUserInputDTO->BankAccountCode = $bankAccountCode;
			}

			if (!empty($order->data['transaction_id'])) {
				$ShopingCartUserInputDTO->PaymentTrackingCode = $order->data['transaction_id'];
			} else {
				$ShopingCartUserInputDTO->PaymentTrackingCode = "0000";
			}

			if ($setting->parmis_shop_debug_mode) {
				ob_start();
				var_dump($ShopingCartUserInputDTO);
				$requestData = ob_get_clean();

				echo '<h4 dir="ltr">add_order<br>OrderData: ' . json_encode($requestData, JSON_UNESCAPED_UNICODE) . '</h4>';

				self::parmis_shop_loader()->parmis_error_log(basename(__FILE__), __LINE__, 'OrderData: ' . json_encode($ShopingCartUserInputDTO, true));
			}

			$countryCode = $order->get_billing_country();
			$stateCode = $order->get_billing_state();
			$stateName = WC()->countries->get_states($countryCode)[$stateCode];
			$cityName = $order->get_billing_city();

			$contactDTO = new stdClass();
			$contactDTO->firstName = $order->get_billing_first_name();
			$contactDTO->lastName = $order->get_billing_last_name();
			$contactDTO->email = $order->get_billing_email();
			$contactDTO->mobileNumber = self::parse_mobile_no($order->get_billing_phone());
			$contactDTO->state = $stateName;
			$contactDTO->city = $cityName;
			$contactDTO->addressDetail = $order->get_billing_address_1() . '، ' . $order->get_billing_address_2();
			$contactDTO->postalCode = $order->get_billing_postcode();

			$postReqParams = [
				"item1" => $ShopingCartUserInputDTO,
				"item2" => $contactDTO
			];
			$result = self::call_post2("WebShopThirdParty/AddOrderWithCustomer",  $ShopingCartUserInputDTO,$contactDTO);

			if ($setting->parmis_shop_debug_mode) {
				echo '<h4 dir="ltr">add_order<br>Result: ' . $result . '</h4>';
			}

			if (!$result->isSuccess && !empty($result->failMessage) && self::str_contains2($result->failMessage, "تفصیلی")) {
				// $customerId = self::save_or_get_customer_id($order, true);
				// $ShopingCartUserInputDTO->CounterpartyID = $customerId;

				$result = self::call_post2("WebShopThirdParty/AddOrderWithCustomer",  $ShopingCartUserInputDTO,$contactDTO);
				if ($setting->parmis_shop_debug_mode) {
					self::parmis_shop_loader()->parmis_error_log(basename(__FILE__), __LINE__, 'Result_!isSuccess: ' . $result);
				}
			}

			$inDbRes = $wpdb->get_results("SELECT * FROM " . $table_prefix . "star_send_log WHERE order_id = " . $order->id);
			if (!empty($inDbRes)) {
				if ($inDbRes[0]->is_sent) return;
			}

			if ($result->message && self::str_contains2($result->message, "تکراری")) {
				$wpdb->update(
					$table_prefix . 'star_send_log',
					array(
						'star_serial'     		=>  '0',
						'is_sent'     			=>  true,
						'fail_message' 		    =>  '',
						'fail_detail_message'   =>  '',
						'send_date'             => current_time('mysql')
					),
					array(
						'order_id'			    => $order->id
					)
				);
			} else {
				$wpdb->update(
					$table_prefix . 'star_send_log',
					array(
						'star_serial'     		=>  $result->result->serial,
						'is_sent'     			=>  $result->isSuccess,
						'fail_message' 		    =>  $result->message,
						'fail_detail_message'   =>  $result->result->failMessage,
						'send_date'             => current_time('mysql')
					),
					array(
						'order_id'			    => $order->id
					)
				);
			}

			$inDbRes = $wpdb->get_results("SELECT * FROM " . $table_prefix . "star_send_log WHERE order_id = " . $order->id);
			if (!empty($inDbRes)) {
				return $inDbRes[0];
			}
		} 
		catch (Exception $e) {
			$wpdb->update(
				$table_prefix . 'star_send_log',
				array(
					'fail_message'	=>	$e->getMessage(),
					'fail_detail_message'   =>  "exception"
				),
				array(
					'order_id'		=>	$order->id
				)
			);

			$inDbRes = $wpdb->get_results("SELECT * FROM " . $table_prefix . "star_send_log WHERE order_id = " . $order->id);
			if (!empty($inDbRes)) {
				return $inDbRes[0];
			}
			self::parmis_shop_loader()->parmis_error_log(basename(__FILE__), __LINE__, 'order_id: ' . $e->getMessage());
		}
	}

	private function save_or_get_customer_id($order, $force_refresh)
	{
		global $wpdb;
		global $table_prefix;
		$setting = self::get_settings();

		if (!$setting->parmis_shop_save_customer) {
			return $setting->parmis_shop_counterparty;
		} else {
			if (!$force_refresh) {
				$customerCode = $wpdb->get_results("SELECT star_customer_id FROM " . $table_prefix . "star_customer_rel WHERE customer_id = " . $order->get_customer_id());

				if (empty($customerCode)) {
					$code = self::save_customer($order);
					return $code;
				} else {
					return $customerCode[0]->star_customer_id;
				}
			} else {
				return self::save_customer($order);
			}
		}
	}

	private function save_customer($order)
	{
		global $wpdb;
		global $table_prefix;
		$setting = self::get_settings();

		$countryCode = $order->get_billing_country();
		$stateCode = $order->get_billing_state();
		$stateName = WC()->countries->get_states($countryCode)[$stateCode];
		$cityName = $order->get_billing_city();

		$contactDTO = new stdClass();
		$contactDTO->firstName = $order->get_billing_first_name();
		$contactDTO->lastName = $order->get_billing_last_name();
		$contactDTO->email = $order->get_billing_email();
		$contactDTO->mobileNumber = self::parse_mobile_no($order->get_billing_phone());
		$contactDTO->state = $stateName;
		$contactDTO->city = $cityName;
		$contactDTO->addressDetail = $order->get_billing_address_1() . '، ' . $order->get_billing_address_2();
		$contactDTO->postalCode = $order->get_billing_postcode();

		if ($setting->parmis_shop_debug_mode) {
			ob_start();
			var_dump($contactDTO);
			$requestData = ob_get_clean();

			echo ('<h4 dir="ltr">save_customer <br>' . 'ContactDTO: ' . $requestData . '</h4>');
			$this->parmis_shop_loader()->parmis_error_log(basename(__FILE__), __LINE__, 'ContactDTO: ' . $requestData);
		}

		$result = self::call_post("WebShopThirdParty/AddCustomer", $contactDTO);

		if ($setting->parmis_shop_debug_mode) {
			ob_start();
			var_dump($result);
			$responseData = ob_get_clean();

			echo ('<h4 dir="ltr">save_customer <br>' . 'Result: ' . $responseData . '</h4>');
			$this->parmis_shop_loader()->parmis_error_log(basename(__FILE__), __LINE__, 'Result: ' . $responseData);
		}

		if ($result->isSuccess) {
			$wpdb->get_results("DELETE FROM " . $table_prefix . "star_customer_rel WHERE customer_id = " . $order->get_customer_id());
			$wpdb->insert(
				$table_prefix . 'star_customer_rel',
				array(
					'customer_id'     => $order->get_customer_id(),
					'star_customer_id'    => $result->message
				)
			);

			return $result->message;
		} else {
			throw new Exception('Customer: ' . $result->message);
			$this->parmis_shop_loader()->parmis_error_log(basename(__FILE__), __LINE__, 'Customer: ' . $result->message);
		}
	}

	private function save_order($userInputDTO)
	{
		$setting = self::get_settings();
		$authenticationDTO = new stdClass();
		$authenticationDTO->accountKey = $setting->parmis_shop_account_key;
		$authenticationDTO->accountType = 4;
		$authenticationDTO->userName = $setting->parmis_shop_username;
		$authenticationDTO->password = $setting->parmis_shop_password;

		$curl = curl_init($setting->parmis_shop_base_url . "api/WebShopThirdParty/AddOrder");
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($curl, CURLOPT_HTTPHEADER, array("Content-Type: application/json"));
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode(["item1" => $authenticationDTO, "item2" => $userInputDTO]));

		$result = curl_exec($curl);
		$httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
		$error = curl_error($curl);
		curl_close($curl);

		if ($httpCode != 200) {
			throw new Exception($error);
			$this->parmis_shop_loader()->parmis_error_log(basename(__FILE__), __LINE__, $error);
		}

		return json_decode($result);
	}

	private function get_bank_account_code($paymentKey)
	{
		global $wpdb;
		global $table_prefix;
		$parmis_shop_payment_key = $wpdb->get_results("SELECT * FROM `" . $table_prefix . "options` WHERE `option_name`= 'parmis_shop_payment_key_$paymentKey'", OBJECT);
		if (!empty($parmis_shop_payment_key)) {
			return $parmis_shop_payment_key[0]->option_value;
		}
	}

	private function parse_mobile_no($mobileNo)
	{
		if (substr($mobileNo, 0, 1) === '+' && strlen($mobileNo) == 13) {
			return '0' . substr($mobileNo, 3);
		} else if ((substr($mobileNo, 0, 1) === '9' && strlen($mobileNo) == 12)) {
			return '0' . substr($mobileNo, 2);
		} else if ((substr($mobileNo, 0, 1) === '9' && strlen($mobileNo) == 10)) {
			return '0' . $mobileNo;
		} else {
			return $mobileNo;
		}
	}

	public function delete_payment_key($paymentKey)
	{
		global $wpdb;
		global $table_prefix;
		$wpdb->get_results("DELETE FROM " . $table_prefix . "options WHERE option_name = '" . $paymentKey . "'");
		return 'درگاه با موفقیت حذف شد';
	}
	#end of add order

	private function call_get($address)
	{
		$setting = self::get_settings();
		$curl = curl_init($setting->parmis_shop_base_url . "api/" . $address);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "GET");
		curl_setopt($curl, CURLOPT_HTTPHEADER, array("Content-Type: application/json"));
		$result = curl_exec($curl);
		$httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
		$error = curl_error($curl);
		curl_close($curl);

		if ($setting->parmis_shop_debug_mode) {
			ob_start();
			$requestData = ob_get_clean();

			ob_start();
			var_dump($result);
			$resultData = ob_get_clean();

			echo ('<h4 dir="ltr">GET address: ' . $address . '<br>' . 'Request: ' . $requestData . '<br>' . 'Result: ' . $resultData . '</h4>');

			$this->parmis_shop_loader()->parmis_error_log(basename(__FILE__), __LINE__, $error);
		}

		return self::parse_result($httpCode, $result, $address);
	}

	private function call_post2($address, $parameter1,$parameter2)
	{
		$setting = self::get_settings();
		$authenticationDTO = new stdClass();
		$authenticationDTO->accountKey = $setting->parmis_shop_account_key;
		$authenticationDTO->accountType = 4;
		$authenticationDTO->userName = $setting->parmis_shop_username;
		$authenticationDTO->password = $setting->parmis_shop_password;

		$curl = curl_init($setting->parmis_shop_base_url . "api/" . $address);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($curl, CURLOPT_HTTPHEADER, array("Content-Type: application/json"));
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode(["item1" => $authenticationDTO, "item2" => $parameter1,"item3" => $parameter2]));

		if ($setting->parmis_shop_debug_mode) {
			self::parmis_shop_loader()->parmis_error_log(basename(__FILE__), __LINE__, var_export($parameter1, true));
			self::parmis_shop_loader()->parmis_error_log(basename(__FILE__), __LINE__, var_export($parameter2, true));
		}

		$result = curl_exec($curl);

		if ($setting->parmis_shop_debug_mode) {
			self::parmis_shop_loader()->parmis_error_log(basename(__FILE__), __LINE__, mb_convert_encoding(var_export($result, true), 'UTF-8', 'auto'));
		}

		$httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
		$errorNo = curl_errno($curl);
		$error = curl_error($curl);
		curl_close($curl);

		if ($setting->parmis_shop_debug_mode) {
			var_dump($authenticationDTO);

			ob_start();
			var_dump($parameter);
			$requestData = ob_get_clean();

			ob_start();
			var_dump($result);
			$resultData = ob_get_clean();

			echo ('<h4 dir="ltr">POST address: ' . $address . '<br>' . 'Request: ' . $requestData . '<br>' . 'Result: ' . $resultData . '</h4>');

			self::parmis_shop_loader()->parmis_error_log(basename(__FILE__), __LINE__, 'Address: ' . $address . '|| Request: ' . $requestData . '|| Result: ' . $resultData);

			echo (var_dump($errorNo) . ' ' . var_dump($error));

			self::parmis_shop_loader()->parmis_error_log(basename(__FILE__), __LINE__, $errorNo . '||' . $errorNo);
		}

		return self::parse_result($httpCode, $result, $address);
	}

	private function call_post($address, $parameter)
	{
		$setting = self::get_settings();
		$authenticationDTO = new stdClass();
		$authenticationDTO->accountKey = $setting->parmis_shop_account_key;
		$authenticationDTO->accountType = 4;
		$authenticationDTO->userName = $setting->parmis_shop_username;
		$authenticationDTO->password = $setting->parmis_shop_password;

		$curl = curl_init($setting->parmis_shop_base_url . "api/" . $address);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($curl, CURLOPT_HTTPHEADER, array("Content-Type: application/json"));
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode(["item1" => $authenticationDTO, "item2" => $parameter]));

		if ($setting->parmis_shop_debug_mode) {
			self::parmis_shop_loader()->parmis_error_log(basename(__FILE__), __LINE__, var_export($parameter, true));
		}

		$result = curl_exec($curl);

		if ($setting->parmis_shop_debug_mode) {
			self::parmis_shop_loader()->parmis_error_log(basename(__FILE__), __LINE__, mb_convert_encoding(var_export($result, true), 'UTF-8', 'auto'));
		}

		$httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
		$errorNo = curl_errno($curl);
		$error = curl_error($curl);
		curl_close($curl);

		if ($setting->parmis_shop_debug_mode) {
			var_dump($authenticationDTO);

			ob_start();
			var_dump($parameter);
			$requestData = ob_get_clean();

			ob_start();
			var_dump($result);
			$resultData = ob_get_clean();

			echo ('<h4 dir="ltr">POST address: ' . $address . '<br>' . 'Request: ' . $requestData . '<br>' . 'Result: ' . $resultData . '</h4>');

			self::parmis_shop_loader()->parmis_error_log(basename(__FILE__), __LINE__, 'Address: ' . $address . '|| Request: ' . $requestData . '|| Result: ' . $resultData);

			echo (var_dump($errorNo) . ' ' . var_dump($error));

			self::parmis_shop_loader()->parmis_error_log(basename(__FILE__), __LINE__, $errorNo . '||' . $errorNo);
		}

		return self::parse_result($httpCode, $result, $address);
	}

	private function parse_result($httpCode, $result, $address)
	{
		$setting = self::get_settings();
		$http_message = null;
		if ($httpCode == 0) {
			$http_message = "سرویس استار در دسترس نیست";
			throw new Exception($http_message);
		} else if ($httpCode != 200) {
			$pattern = "#<title>.*</title>#";
			$matches = array();
			if (preg_match($pattern, $result, $matches)) {
				$http_message = 'Url: ' . $address . '<br>' . 'Error code: ' . $httpCode . '<br>' . 'Message: ' . $matches[0];
				throw new Exception($http_message);
			} else {
				$http_message = 'Url: ' . $address . '<br>' . 'Error code: ' . $httpCode . '<br>' . 'Message: ' . $result;
				throw new Exception($http_message);
			}
		}
		if ($setting->parmis_shop_debug_mode) {
			self::parmis_shop_loader()->parmis_error_log(basename(__FILE__), __LINE__, 'Code: ' . $httpCode . '|| Result: ' . $result . '|| Address: ' . $address);
		}
		$json = json_decode($result);
		if ($json == null) {
			$json_message = 'Url: ' . $address . '<br>' . 'Message: ' . strip_tags($result);
			throw new Exception($json_message);
			if ($setting->parmis_shop_debug_mode) {
				self::parmis_shop_loader()->parmis_error_log(basename(__FILE__), __LINE__, $json_message);
			}
		} else {
			if ($setting->parmis_shop_debug_mode) {
				self::parmis_shop_loader()->parmis_error_log(basename(__FILE__), __LINE__, var_export($json, true));
			}
			return $json;
		}
	}

	public static function save_settings(
		$accountkey,
		$username,
		$password,
		$customerUsername,
		$customerPassword,
		$station,
		$paymentKeys,
		$accounts,
		$counterparty,
		$url,
		$saveCustomer,
		$updateQuantities,
		$updatePrices,
		$isToman,
		$debugMode,
		$paymentCriteria,
		$ordertypesubmit,
		$schedule_status,
		$schedule_interval
	) {
		global $wpdb;
		global $table_prefix;
		$parmis_shop_username = $wpdb->get_results("SELECT * FROM `" . $table_prefix . "options` WHERE `option_name` ='parmis_shop_username'", OBJECT);
		if (empty($parmis_shop_username) || count($parmis_shop_username) == 0) {
			$wpdb->insert(
				$table_prefix . 'options',
				array(
					'option_name'     => 'parmis_shop_username',
					'option_value'    => $username,
				)
			);
		} else {
			$wpdb->update(
				$table_prefix . 'options',
				array(
					'option_value'     =>  $username,
				),
				array(
					'option_name'     => 'parmis_shop_username'
				)
			);
		}


		$parmis_shop_base_url = $wpdb->get_results("SELECT * FROM `" . $table_prefix . "options` WHERE `option_name` ='parmis_shop_base_url'", OBJECT);
		if (empty($parmis_shop_base_url) || count($parmis_shop_base_url) == 0) {
			$wpdb->insert(
				$table_prefix . 'options',
				array(
					'option_name'     => 'parmis_shop_base_url',
					'option_value'    => $url,
				)
			);
		} else {
			$wpdb->update(
				$table_prefix . 'options',
				array(
					'option_value'     =>  $url,
				),
				array(
					'option_name'     => 'parmis_shop_base_url'
				)
			);
		}

		$parmis_shop_password = $wpdb->get_results("SELECT * FROM `" . $table_prefix . "options` WHERE `option_name` ='parmis_shop_password'", OBJECT);
		if (empty($parmis_shop_password) || count($parmis_shop_password) == 0) {
			$wpdb->insert(
				$table_prefix . 'options',
				array(
					'option_name'     => 'parmis_shop_password',
					'option_value'    => $password,
				)
			);
		} else {
			$wpdb->update(
				$table_prefix . 'options',
				array(
					'option_value'     =>  $password,
				),
				array(
					'option_name'     => 'parmis_shop_password'
				)
			);
		}


		$parmis_shop_customer_username = $wpdb->get_results("SELECT * FROM `" . $table_prefix . "options` WHERE `option_name` ='parmis_shop_customer_username'", OBJECT);
		if (empty($parmis_shop_customer_username) || count($parmis_shop_customer_username) == 0) {
			$wpdb->insert(
				$table_prefix . 'options',
				array(
					'option_name'     => 'parmis_shop_customer_username',
					'option_value'    => $customerUsername,
				)
			);
		} else {
			$wpdb->update(
				$table_prefix . 'options',
				array(
					'option_value'     =>  $customerUsername,
				),
				array(
					'option_name'     => 'parmis_shop_customer_username'
				)
			);
		}

		$parmis_shop_customer_password = $wpdb->get_results("SELECT * FROM `" . $table_prefix . "options` WHERE `option_name` ='parmis_shop_customer_password'", OBJECT);
		if (empty($parmis_shop_customer_password) || count($parmis_shop_customer_password) == 0) {
			$wpdb->insert(
				$table_prefix . 'options',
				array(
					'option_name'     => 'parmis_shop_customer_password',
					'option_value'    => $customerPassword,
				)
			);
		} else {
			$wpdb->update(
				$table_prefix . 'options',
				array(
					'option_value'     =>  $customerPassword,
				),
				array(
					'option_name'     => 'parmis_shop_customer_password'
				)
			);
		}


		$parmis_shop_station = $wpdb->get_results("SELECT * FROM `" . $table_prefix . "options` WHERE `option_name` ='parmis_shop_station'", OBJECT);
		if (empty($parmis_shop_station) || count($parmis_shop_station) == 0) {
			$wpdb->insert(
				$table_prefix . 'options',
				array(
					'option_name'     => 'parmis_shop_station',
					'option_value'    => $station,
				)
			);
		} else {
			$wpdb->update(
				$table_prefix . 'options',
				array(
					'option_value'     =>  $station,
				),
				array(
					'option_name'     => 'parmis_shop_station'
				)
			);
		}



		$parmis_shop_account_key = $wpdb->get_results("SELECT * FROM `" . $table_prefix . "options` WHERE `option_name` ='parmis_shop_account_key'", OBJECT);
		if (empty($parmis_shop_account_key) || count($parmis_shop_account_key) == 0) {
			$wpdb->insert(
				$table_prefix . 'options',
				array(
					'option_name'     => 'parmis_shop_account_key',
					'option_value'    => $accountkey,
				)
			);
		} else {
			$wpdb->update(
				$table_prefix . 'options',
				array(
					'option_value'     =>  $accountkey,
				),
				array(
					'option_name'     => 'parmis_shop_account_key'
				)
			);
		}


		$parmis_shop_counterparty = $wpdb->get_results("SELECT * FROM `" . $table_prefix . "options` WHERE `option_name` ='parmis_shop_counterparty'", OBJECT);
		if (empty($parmis_shop_counterparty) || count($parmis_shop_counterparty) == 0) {
			$wpdb->insert(
				$table_prefix . 'options',
				array(
					'option_name'     => 'parmis_shop_counterparty',
					'option_value'    => $counterparty,
				)
			);
		} else {
			$wpdb->update(
				$table_prefix . 'options',
				array(
					'option_value'     =>  $counterparty,
				),
				array(
					'option_name'     => 'parmis_shop_counterparty'
				)
			);
		}

		$parmis_shop_save_customer = $wpdb->get_results("SELECT * FROM `" . $table_prefix . "options` WHERE `option_name` ='parmis_shop_save_customer'", OBJECT);
		$save_customer_value = !empty($saveCustomer);
		if (empty($parmis_shop_save_customer) || count($parmis_shop_save_customer) == 0) {
			$wpdb->insert(
				$table_prefix . 'options',
				array(
					'option_name'     => 'parmis_shop_save_customer',
					'option_value'    => $save_customer_value,
				)
			);
		} else {
			$wpdb->update(
				$table_prefix . 'options',
				array(
					'option_value'     =>  $save_customer_value,
				),
				array(
					'option_name'     => 'parmis_shop_save_customer'
				)
			);
		}

		$parmis_shop_update_quantities = $wpdb->get_results("SELECT * FROM `" . $table_prefix . "options` WHERE `option_name` ='parmis_shop_update_quantities'", OBJECT);
		$update_quantities_value = !empty($updateQuantities);
		if (empty($parmis_shop_update_quantities) || count($parmis_shop_update_quantities) == 0) {
			$wpdb->insert(
				$table_prefix . 'options',
				array(
					'option_name'     => 'parmis_shop_update_quantities',
					'option_value'    => $update_quantities_value,
				)
			);
		} else {
			$wpdb->update(
				$table_prefix . 'options',
				array(
					'option_value'     =>  $update_quantities_value,
				),
				array(
					'option_name'     => 'parmis_shop_update_quantities'
				)
			);
		}

		$parmis_shop_update_prices = $wpdb->get_results("SELECT * FROM `" . $table_prefix . "options` WHERE `option_name` ='parmis_shop_update_prices'", OBJECT);
		$update_prices_value = !empty($updatePrices);
		if (empty($parmis_shop_update_prices) || count($parmis_shop_update_prices) == 0) {
			$wpdb->insert(
				$table_prefix . 'options',
				array(
					'option_name'     => 'parmis_shop_update_prices',
					'option_value'    => $update_prices_value,
				)
			);
		} else {
			$wpdb->update(
				$table_prefix . 'options',
				array(
					'option_value'     =>  $update_prices_value,
				),
				array(
					'option_name'     => 'parmis_shop_update_prices'
				)
			);
		}

		$parmis_shop_is_toman = $wpdb->get_results("SELECT * FROM `" . $table_prefix . "options` WHERE `option_name` ='parmis_shop_is_toman'", OBJECT);
		$is_toman_value = !empty($isToman);
		if (empty($parmis_shop_is_toman) || count($parmis_shop_is_toman) == 0) {
			$wpdb->insert(
				$table_prefix . 'options',
				array(
					'option_name'     => 'parmis_shop_is_toman',
					'option_value'    => $is_toman_value,
				)
			);
		} else {
			$wpdb->update(
				$table_prefix . 'options',
				array(
					'option_value'     =>  $is_toman_value,
				),
				array(
					'option_name'     => 'parmis_shop_is_toman'
				)
			);
		}

		$parmis_shop_debug_mode = $wpdb->get_results("SELECT * FROM `" . $table_prefix . "options` WHERE `option_name` ='parmis_shop_debug_mode'", OBJECT);
		$is_debug_mode_value = !empty($debugMode);
		if (empty($parmis_shop_debug_mode) || count($parmis_shop_debug_mode) == 0) {
			$wpdb->insert(
				$table_prefix . 'options',
				array(
					'option_name'     => 'parmis_shop_debug_mode',
					'option_value'    => $is_debug_mode_value,
				)
			);
		} else {
			$wpdb->update(
				$table_prefix . 'options',
				array(
					'option_value'     =>  $is_debug_mode_value,
				),
				array(
					'option_name'     => 'parmis_shop_debug_mode'
				)
			);
		}

		$parmis_payment_criteria_api = $wpdb->get_results("SELECT * FROM `" . $table_prefix . "options` WHERE `option_name` ='parmis_payment_criteria_api'", OBJECT);
		$is_payment_criteria_api = !empty($paymentCriteria);
		if (empty($parmis_payment_criteria_api) || count($parmis_payment_criteria_api) == 0) {
			$wpdb->insert(
				$table_prefix . 'options',
				array(
					'option_name'     => 'parmis_payment_criteria_api',
					'option_value'    => $is_payment_criteria_api,
				)
			);
		} else {
			$wpdb->update(
				$table_prefix . 'options',
				array(
					'option_value'     =>  $is_payment_criteria_api,
				),
				array(
					'option_name'     => 'parmis_payment_criteria_api'
				)
			);
		}

		$parmis_order_submission_type = get_option('parmis_order_type_submit');
		$parmis_order_submission_type_value = in_array((int) $ordertypesubmit, range(1, 4)) ? (int) $ordertypesubmit : 0;
		if (empty($parmis_order_submission_type)) {
			add_option('parmis_order_type_submit', $parmis_order_submission_type_value);
		} else {
			update_option('parmis_order_type_submit', $parmis_order_submission_type_value);
		}

		$parmis_schedule_status = get_option('parmis_schedule_status');
		$parmis_schedue_status_input = !empty($schedule_status);
		if (!isset($parmis_schedule_status)) {
			add_option('parmis_schedule_status', $parmis_schedue_status_input);
		} else {
			update_option('parmis_schedule_status', $parmis_schedue_status_input);
		}

		$parmis_schedule_interval = get_option('parmis_schedule_interval');
		$parmis_schedule_interval_value = (int) $schedule_interval;
		if (!isset($parmis_schedule_interval)) {
			add_option('parmis_schedule_interval', $parmis_schedule_interval_value);
		} else {
			update_option('parmis_schedule_interval', $parmis_schedule_interval_value);
			// update schedule event update parmis
			$timestamp = wp_next_scheduled('parmis_update_schedule_event');
			if (false !== wp_get_scheduled_event('parmis_update_schedule_event')) {
				wp_unschedule_event($timestamp, 'parmis_update_schedule_event');
				wp_schedule_event(time(), 'parmis_custom_interval', 'parmis_update_schedule_event');
			}
		}


		$index = 0;
		foreach ($paymentKeys as $paymentKey) {
			if (!empty($paymentKey)) {

				$parmis_shop_payment_key = $wpdb->get_results("SELECT * FROM `" . $table_prefix . "options` WHERE `option_name` ='parmis_shop_payment_key_$paymentKey'", OBJECT);
				if (empty($parmis_shop_payment_key) || count($parmis_shop_payment_key) == 0) {
					$wpdb->insert(
						$table_prefix . 'options',
						array(
							'option_name'     => "parmis_shop_payment_key_$paymentKey",
							'option_value'    => $accounts[$index],
						)
					);
				} else {
					$wpdb->update(
						$table_prefix . 'options',
						array(
							'option_value'     =>  $accounts[$index],
						),
						array(
							'option_name'     => "parmis_shop_payment_key_$paymentKey"
						)
					);
				}
			}
			$index++;
		}

		return 'ذخیره تغییرات با موفقیت انجام شد';
	}

	public static function get_settings()
	{
		global $wpdb;
		global $table_prefix;

		$result = new stdClass();
		$result->parmis_shop_username = "";
		$result->parmis_shop_password = "";
		$result->parmis_shop_customer_username = "";
		$result->parmis_shop_customer_password = "";
		$result->parmis_shop_station = "";
		$result->parmis_shop_account_key = "";
		$result->parmis_shop_counterparty = "";
		$result->parmis_shop_payment_keys = [];
		$result->parmis_shop_base_url = "";
		$result->parmis_shop_save_customer = false;
		$result->parmis_shop_update_quantities = false;
		$result->parmis_shop_update_prices = false;
		$result->parmis_shop_is_toman = false;
		$result->parmis_shop_debug_mode = false;
		$result->parmis_shop_payment_criteria_api = false;
		$result->parmis_shop_order_submission_type = 0;
		$result->parmis_schedule_status = false;
		$result->parmis_schedule_interval = 0;

		$parmis_shop_base_url = $wpdb->get_results("SELECT * FROM `" . $table_prefix . "options` WHERE `option_name` ='parmis_shop_base_url'", OBJECT);
		if (!empty($parmis_shop_base_url)) {
			$result->parmis_shop_base_url = $parmis_shop_base_url[0]->option_value;
		}

		$parmis_shop_username = $wpdb->get_results("SELECT * FROM `" . $table_prefix . "options` WHERE `option_name` ='parmis_shop_username'", OBJECT);
		if (!empty($parmis_shop_username)) {
			$result->parmis_shop_username = $parmis_shop_username[0]->option_value;
		}


		$parmis_shop_password = $wpdb->get_results("SELECT * FROM `" . $table_prefix . "options` WHERE `option_name` ='parmis_shop_password'", OBJECT);
		if (!empty($parmis_shop_password)) {
			$result->parmis_shop_password = $parmis_shop_password[0]->option_value;
		}


		$parmis_shop_customer_username = $wpdb->get_results("SELECT * FROM `" . $table_prefix . "options` WHERE `option_name` ='parmis_shop_customer_username'", OBJECT);
		if (!empty($parmis_shop_customer_username)) {
			$result->parmis_shop_customer_username = $parmis_shop_customer_username[0]->option_value;
		}

		$parmis_shop_customer_password = $wpdb->get_results("SELECT * FROM `" . $table_prefix . "options` WHERE `option_name` ='parmis_shop_customer_password'", OBJECT);

		if (!empty($parmis_shop_customer_password)) {
			$result->parmis_shop_customer_password = $parmis_shop_customer_password[0]->option_value;
		}

		$parmis_shop_station = $wpdb->get_results("SELECT * FROM `" . $table_prefix . "options` WHERE `option_name` ='parmis_shop_station'", OBJECT);
		if (!empty($parmis_shop_station)) {
			$result->parmis_shop_station = $parmis_shop_station[0]->option_value;
		}


		$parmis_shop_account_key = $wpdb->get_results("SELECT * FROM `" . $table_prefix . "options` WHERE `option_name` ='parmis_shop_account_key'", OBJECT);
		if (!empty($parmis_shop_account_key)) {
			$result->parmis_shop_account_key = $parmis_shop_account_key[0]->option_value;
		}

		$parmis_shop_counterparty = $wpdb->get_results("SELECT * FROM `" . $table_prefix . "options` WHERE `option_name` ='parmis_shop_counterparty'", OBJECT);
		if (!empty($parmis_shop_counterparty)) {
			$result->parmis_shop_counterparty = $parmis_shop_counterparty[0]->option_value;
		}

		$parmis_shop_save_customer = $wpdb->get_results("SELECT * FROM `" . $table_prefix . "options` WHERE `option_name` ='parmis_shop_save_customer'", OBJECT);
		if (!empty($parmis_shop_save_customer)) {
			if (empty($parmis_shop_save_customer[0]->option_value) || $parmis_shop_save_customer[0]->option_value == "0") {
				$result->parmis_shop_save_customer = false;
			} else {
				$result->parmis_shop_save_customer = true;
			}
		}

		$parmis_shop_update_quantities = $wpdb->get_results("SELECT * FROM `" . $table_prefix . "options` WHERE `option_name` ='parmis_shop_update_quantities'", OBJECT);
		if (!empty($parmis_shop_update_quantities)) {
			if (empty($parmis_shop_update_quantities[0]->option_value) || $parmis_shop_update_quantities[0]->option_value == "0") {
				$result->parmis_shop_update_quantities = false;
			} else {
				$result->parmis_shop_update_quantities = true;
			}
		}

		$parmis_shop_update_prices = $wpdb->get_results("SELECT * FROM `" . $table_prefix . "options` WHERE `option_name` ='parmis_shop_update_prices'", OBJECT);
		if (!empty($parmis_shop_update_prices)) {
			if (empty($parmis_shop_update_prices[0]->option_value) || $parmis_shop_update_prices[0]->option_value == "0") {
				$result->parmis_shop_update_prices = false;
			} else {
				$result->parmis_shop_update_prices = true;
			}
		}

		$parmis_shop_is_toman = $wpdb->get_results("SELECT * FROM `" . $table_prefix . "options` WHERE `option_name` ='parmis_shop_is_toman'", OBJECT);
		if (!empty($parmis_shop_is_toman)) {
			if (empty($parmis_shop_is_toman[0]->option_value) || $parmis_shop_is_toman[0]->option_value == "0") {
				$result->parmis_shop_is_toman = false;
			} else {
				$result->parmis_shop_is_toman = true;
			}
		}

		$parmis_shop_debug_mode = $wpdb->get_results("SELECT * FROM `" . $table_prefix . "options` WHERE `option_name` ='parmis_shop_debug_mode'", OBJECT);
		if (!empty($parmis_shop_debug_mode)) {
			if (empty($parmis_shop_debug_mode[0]->option_value) || $parmis_shop_debug_mode[0]->option_value == "0") {
				$result->parmis_shop_debug_mode = false;
			} else {
				$result->parmis_shop_debug_mode = true;
			}
		}

		$parmis_shop_payment_criteria_api = $wpdb->get_results("SELECT * FROM `" . $table_prefix . "options` WHERE `option_name` ='parmis_payment_criteria_api'", OBJECT);
		if (!empty($parmis_shop_payment_criteria_api)) {
			if (empty($parmis_shop_payment_criteria_api[0]->option_value) || $parmis_shop_payment_criteria_api[0]->option_value == "0") {
				$result->parmis_shop_payment_criteria_api = false;
			} else {
				$result->parmis_shop_payment_criteria_api = true;
			}
		}

		$parmis_shop_payment_keys = $wpdb->get_results("SELECT * FROM `" . $table_prefix . "options` WHERE `option_name` like 'parmis_shop_payment_key_%'", OBJECT);
		foreach ($parmis_shop_payment_keys as $parmis_shop_payment_key) {
			$item = new stdClass();

			$item->payment_key = str_replace('parmis_shop_payment_key_', "", $parmis_shop_payment_key->option_name);
			$item->payment_value = $parmis_shop_payment_key->option_value;

			$result->parmis_shop_payment_keys[] = $item;
		}

		$parmis_shop_order_submission_type = get_option('parmis_order_type_submit');
		if (!empty($parmis_shop_order_submission_type)) {
			$result->parmis_shop_order_submission_type = (int) $parmis_shop_order_submission_type;
		} else {
			$result->parmis_shop_order_submission_type = 0;
		}

		$parmis_schedule_status_value = get_option('parmis_schedule_status');
		if (!empty($parmis_schedule_status_value)) {
			$result->parmis_schedule_status = true;
		} else {
			$result->parmis_schedule_status = false;
		}

		$parmis_schedule_interval = get_option('parmis_schedule_interval');
		if (isset($parmis_schedule_interval)) {
			$result->parmis_schedule_interval = $parmis_schedule_interval;
		} else {
			$result->parmis_schedule_interval = 0;
		}

		return $result;
	}
	/** 
	 * check api availability 
	 */
	public static function ParmisApiStatus()
	{
		$setting = self::get_settings();
		$curl = curl_init();
		curl_setopt_array($curl, [
			CURLOPT_URL => $setting->parmis_shop_base_url . "api/version",
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 30,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "GET",
			CURLOPT_HTTPHEADER => [
				"Content-Type: application/json"
			],
			CURLOPT_SSL_VERIFYPEER => 0,
			CURLOPT_SSL_VERIFYHOST => 0
		]);
		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);
		if (!empty($response)) {
			return true;
		} else {
			if ($setting->parmis_shop_debug_mode) {
				self::parmis_shop_loader()->parmis_error_log(basename(__FILE__), __LINE__, $err);
			}
			return false;
		}
	}
	/**
	 * if api is not available disable checkout proceed 
	 */
	public static function parmis_checkout_ajax_callback()
	{
		if (!wp_verify_nonce($_POST['nonce'], 'parmis_shop_object_nonce')) {
			wp_die();
		}
		$setting = self::get_settings();
		$check_api = self::ParmisApiStatus();
		if ($setting->parmis_shop_payment_criteria_api) {
			return wp_send_json_success([
				(bool) $check_api
			]);
		}
		wp_die();
	}
	/**
	 * Define parmis shop loader class
	 */
	private function parmis_shop_loader()
	{
		return new Parmis_Shop_Loader();
	}
}
