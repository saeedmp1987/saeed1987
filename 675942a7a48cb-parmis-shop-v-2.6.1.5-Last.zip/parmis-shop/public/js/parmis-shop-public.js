(function($) {
    'use strict';

    /**
     * All of the code for your public-facing JavaScript source
     * should reside in this file.
     *
     * Note: It has been assumed you will write jQuery code here, so the
     * $ function reference has been prepared for usage within the scope
     * of this function.
     *
     * This enables you to define handlers, for when the DOM is ready:
     *
     * $(function() {
     *
     * });
     *
     * When the window is loaded:
     *
     * $( window ).load(function() {
     *
     * });
     *
     * ...and/or other possibilities.
     *
     * Ideally, it is not considered best practise to attach more than a
     * single DOM-ready or window-load handler for a particular page.
     * Although scripts in the WordPress core, Plugins and Themes may be
     * practising this, we should strive to set a better example in our own work.
     */

    if (document.body.classList.contains('woocommerce-checkout')) {
        window.addEventListener('load', function() {
            $.ajax({
                url: parmis_shop_object.url,
                type: 'POST',
                data: {
                    action: 'parmis_checkout_ajax',
                    nonce: parmis_shop_object.nonce
                },
                success: function(resp) {
                    if (resp.success) {
                        if (resp.data[0] !== false) { return false };
                        let notice = document.querySelector('.woocommerce-notices-wrapper');
                        notice.insertAdjacentHTML(
                            'afterend',
                            `<div class="woocommerce-error">در حال حاضر مشکلی در اتصال به سیستم مالی پیش آمده است. لطفا ساعاتی دیگر سفارش خود را ثبت کنید.</div>`
                        );
                        let btn = document.querySelector('button#place_order');
                        btn.disabled = true;
                    }
                },
                error: function(req, err) {
                    return false;
                }
            });
        });
    }
    if (document.body.classList.contains('woocommerce-cart')) {
        window.addEventListener('load', function() {
            $.ajax({
                url: parmis_shop_object.url,
                type: 'POST',
                data: {
                    action: 'parmis_checkout_ajax',
                    nonce: parmis_shop_object.nonce
                },
                success: function(resp) {
                    if (resp.success) {
                        if (resp.data[0] !== false) { return false };
                        let notice = document.querySelector('.woocommerce-notices-wrapper');
                        notice.insertAdjacentHTML(
                            'afterend',
                            `<div class="woocommerce-error">در حال حاضر مشکلی در اتصال به سیستم مالی پیش آمده است. لطفا ساعاتی دیگر سفارش خود را ثبت کنید.</div>`
                        );
                        let btn = document.querySelector('a.checkout-button');
                        btn.classList.add('disabled');
                        btn.addEventListener('click', function(e) {
                            e.preventDefault();
                        });
                    }
                },
                error: function(req, err) {
                    return false;
                }
            });
        });
    }
})(jQuery);