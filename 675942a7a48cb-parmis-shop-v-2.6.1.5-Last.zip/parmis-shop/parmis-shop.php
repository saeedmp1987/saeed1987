<?php



/**

 * The plugin bootstrap file

 *

 * This file is read by WordPress to generate the plugin information in the plugin

 * admin area. This file also includes all of the dependencies used by the plugin,

 * registers the activation and deactivation functions, and defines a function

 * that starts the plugin.

 *

 * @link              http://www.ParmisIT.com

 * @since             1.0.0

 * @package           Parmis_Shop

 *

 * @wordpress-plugin

 * Plugin Name:       فروشگاه پارمیس

 * Plugin URI:        http://www.ParmisIT.com

 * Description:       اتصال ووکامرس به سیستم ERP پارمیس استار.

 * Version:           2.6.1.5

 * Author:            Parmis 

 * Author URI:        http://www.ParmisIT.com

 * License:           GPL-2.0+

 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt

 * Text Domain:       parmis-shop

 * Domain Path:       /languages

 */



// If this file is called directly, abort.

if (!defined('WPINC')) {

	die;

}



/**

 * Currently plugin version.

 * Start at version 1.0.0 and use SemVer - https://semver.org

 * Rename this for your plugin and update it as you release new versions.

 */

define('PARMIS_SHOP_VERSION', '2.6.1.5');

define('PARMIS_DEBUG_LOG_FILE' , plugin_dir_path(__FILE__) . 'parmis_debug.log');

/**

 * The code that runs during plugin activation.

 * This action is documented in includes/class-parmis-shop-activator.php

 */

function activate_parmis_shop()

{

	require_once plugin_dir_path(__FILE__) . 'includes/class-parmis-shop-activator.php';

	Parmis_Shop_Activator::activate();

}



/**

 * The code that runs during plugin deactivation.

 * This action is documented in includes/class-parmis-shop-deactivator.php

 */

function deactivate_parmis_shop()

{

	require_once plugin_dir_path(__FILE__) . 'includes/class-parmis-shop-deactivator.php';

	Parmis_Shop_Deactivator::deactivate();

}



register_activation_hook(__FILE__, 'activate_parmis_shop');

register_deactivation_hook(__FILE__, 'deactivate_parmis_shop');



/**

 * The core plugin class that is used to define internationalization,

 * admin-specific hooks, and public-facing site hooks.

 */

require plugin_dir_path(__FILE__) . 'includes/class-parmis-shop.php';



/**

 * Begins execution of the plugin.

 *

 * Since everything within the plugin is registered via hooks,

 * then kicking off the plugin from this point in the file does

 * not affect the page life cycle.

 *

 * @since    1.0.0

 */

function run_parmis_shop()

{



	$plugin = new Parmis_Shop();

	$plugin->run();

}

run_parmis_shop();

