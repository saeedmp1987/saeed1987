<?php

/**
 * Fired during plugin activation
 *
 * @link       http://www.ParmisIT.com
 * @since      1.0.0
 *
 * @package    Parmis_Shop
 * @subpackage Parmis_Shop/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Parmis_Shop
 * @subpackage Parmis_Shop/includes
 * @author     Hassan Azizi <azizi55@ymail.com>
 * @author     kian babai <kian.babai.09@gmail.com>
 */
class Parmis_Shop_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() 
    {
		self::create_tables();
	}

    private function create_tables()
    {
        global $table_prefix, $wpdb;
        $wp_track_table = $table_prefix.'star_product_rel';
        if($wpdb->get_var( "show tables like '$wp_track_table'" ) != $wp_track_table) 
        {

            $sql = "CREATE TABLE `". $wp_track_table . "` ( ";
            $sql .= "  `id`  int(11)   NOT NULL auto_increment, ";
            $sql .= "  `star_id`  varchar(256)   NOT NULL, ";
            $sql .= "  `product_id`  varchar(256)   NOT NULL, ";
            $sql .= "  PRIMARY KEY  (`id`), ";
            $sql .= "  UNIQUE(`id`) ";
            $sql .= ") ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ; ";
            require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
            dbDelta($sql);
        }

        $contactRelTableName = $table_prefix.'star_customer_rel';
        if($wpdb->get_var( "show tables like '$contactRelTableName'" ) != $contactRelTableName) 
        {

            $sql = "CREATE TABLE `". $contactRelTableName . "` ( ";
            $sql .= "  `id`  int(11)   NOT NULL auto_increment, ";
            $sql .= "  `star_customer_id`  varchar(256)   NOT NULL, ";
            $sql .= "  `customer_id`  varchar(256)   NOT NULL, ";
            $sql .= "  PRIMARY KEY  (`id`), ";
            $sql .= "  UNIQUE(`id`) ";
            $sql .= ") ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ; ";
            require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
            dbDelta($sql);
        }

        $sendLogTableName = $table_prefix."star_send_log";
        if($wpdb->get_var( "show tables like '$sendLogTableName'" ) != $sendLogTableName) 
        {

            $sql = "CREATE TABLE `". $sendLogTableName . "` ( ";
            $sql .= "  `id`  int(11) NOT NULL auto_increment, ";
            $sql .= "  `order_id` varchar(256) NOT NULL, ";
            $sql .= "  `order_date` datetime, ";
            $sql .= "  `send_date` datetime, ";
            $sql .= "  `star_serial` varchar(256) NULL, ";
            $sql .= "  `is_sent` boolean  NOT NULL, ";
            $sql .= "  `fail_message` TEXT NULL, ";
            $sql .= "  `fail_detail_message` TEXT NULL, ";
            $sql .= "  PRIMARY KEY  (`id`), ";
            $sql .= "  UNIQUE(`id`) ";
            $sql .= ") ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ; ";
            require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
            dbDelta($sql);
        }
    }
}