<?php

/**
 * Register all actions and filters for the plugin
 *
 * @link       http://www.ParmisIT.com
 * @since      1.0.0
 *
 * @package    Parmis_Shop
 * @subpackage Parmis_Shop/includes
 */

/**
 * Register all actions and filters for the plugin.
 *
 * Maintain a list of all hooks that are registered throughout
 * the plugin, and register them with the WordPress API. Call the
 * run function to execute the list of actions and filters.
 *
 * @package    Parmis_Shop
 * @subpackage Parmis_Shop/includes
 * @author     Hassan Azizi <azizi55@ymail.com>
 */
class Parmis_Shop_Loader
{

	/**
	 * The array of actions registered with WordPress.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      array    $actions    The actions registered with WordPress to fire when the plugin loads.
	 */
	protected $actions;

	/**
	 * The array of filters registered with WordPress.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      array    $filters    The filters registered with WordPress to fire when the plugin loads.
	 */
	protected $filters;

	/**
	 * Initialize the collections used to maintain the actions and filters.
	 *
	 * @since    1.0.0
	 */
	public function __construct()
	{

		$this->actions = array();
		$this->filters = array();

		add_action('woocommerce_before_checkout_form', array($this, 'update_parts'));
		add_action('woocommerce_order_items_table', array($this, 'add_order'), 20, 1);
		add_action('wp_ajax_nopriv_parmis_checkout_ajax', array($this, 'parmis_checkout_ajax_callback_loader'));
		add_action('wp_ajax_parmis_checkout_ajax', array($this, 'parmis_checkout_ajax_callback_loader'));

		add_action('wp_ajax_nopriv_parmis_shop_order_report_update', array($this, 'parmis_shop_order_report_update_callback_loader'));
		add_action('wp_ajax_parmis_shop_order_report_update', array($this, 'parmis_shop_order_report_update_callback_loader'));


		// add_filter('cron_schedules', array($this, 'parmis_custom_schedule_interval')); //custom time interval
		add_action('init', array($this, 'parmis_schedule_update_action'));
		add_action('parmis_update_schedule_event', array($this, 'parmis_schedule_update_action_callback'));
	}

	/**
	 * Add a new action to the collection to be registered with WordPress.
	 *
	 * @since    1.0.0
	 * @param    string               $hook             The name of the WordPress action that is being registered.
	 * @param    object               $component        A reference to the instance of the object on which the action is defined.
	 * @param    string               $callback         The name of the function definition on the $component.
	 * @param    int                  $priority         Optional. The priority at which the function should be fired. Default is 10.
	 * @param    int                  $accepted_args    Optional. The number of arguments that should be passed to the $callback. Default is 1.
	 */
	public function add_action($hook, $component, $callback, $priority = 10, $accepted_args = 1)
	{
		$this->actions = $this->add($this->actions, $hook, $component, $callback, $priority, $accepted_args);
	}

	/**
	 * Add a new filter to the collection to be registered with WordPress.
	 *
	 * @since    1.0.0
	 * @param    string               $hook             The name of the WordPress filter that is being registered.
	 * @param    object               $component        A reference to the instance of the object on which the filter is defined.
	 * @param    string               $callback         The name of the function definition on the $component.
	 * @param    int                  $priority         Optional. The priority at which the function should be fired. Default is 10.
	 * @param    int                  $accepted_args    Optional. The number of arguments that should be passed to the $callback. Default is 1
	 */
	public function add_filter($hook, $component, $callback, $priority = 10, $accepted_args = 1)
	{
		$this->filters = $this->add($this->filters, $hook, $component, $callback, $priority, $accepted_args);
	}

	/**
	 * A utility function that is used to register the actions and hooks into a single
	 * collection.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @param    array                $hooks            The collection of hooks that is being registered (that is, actions or filters).
	 * @param    string               $hook             The name of the WordPress filter that is being registered.
	 * @param    object               $component        A reference to the instance of the object on which the filter is defined.
	 * @param    string               $callback         The name of the function definition on the $component.
	 * @param    int                  $priority         The priority at which the function should be fired.
	 * @param    int                  $accepted_args    The number of arguments that should be passed to the $callback.
	 * @return   array                                  The collection of actions and filters registered with WordPress.
	 */
	private function add($hooks, $hook, $component, $callback, $priority, $accepted_args)
	{

		$hooks[] = array(
			'hook'          => $hook,
			'component'     => $component,
			'callback'      => $callback,
			'priority'      => $priority,
			'accepted_args' => $accepted_args
		);

		return $hooks;
	}

	/**
	 * Register the filters and actions with WordPress.
	 *
	 * @since    1.0.0
	 */
	public function run()
	{

		foreach ($this->filters as $hook) {
			add_filter($hook['hook'], array($hook['component'], $hook['callback']), $hook['priority'], $hook['accepted_args']);
		}

		foreach ($this->actions as $hook) {
			add_action($hook['hook'], array($hook['component'], $hook['callback']), $hook['priority'], $hook['accepted_args']);
		}
	}

	function update_parts()
	{
		$cart = WC()->cart->get_cart();

		Parmis_Shop_Public::update_parts($cart);
	}

	function add_order($order)
	{
		if (!$order->has_status(array('failed', 'pending', 'cancelled',  'on-hold'))) {
			Parmis_Shop_Public::add_order($order);
		}
	}
	function parmis_checkout_ajax_callback_loader()
	{
		Parmis_Shop_Public::parmis_checkout_ajax_callback();
	}
	function parmis_shop_order_report_update_callback_loader()
	{
		Parmis_Shop_Admin::parmis_shop_order_report_update_callback();
	}
	public function parmis_error_log($file, $line, $message)
	{
		error_log(date("[Y-m-d H:i:s]") . " [" . $file . " : on line " . $line . "] " . $message . "\n", 3, PARMIS_DEBUG_LOG_FILE);
	}


	public function parmis_schedule_update_action()
	{
		$interval = get_option('parmis_schedule_interval');


		add_filter('cron_schedules', function ($schedules) use ($interval) {
			$schedules['parmis_custom_interval'] = array(
				'interval' => $interval * 60,
				'display'  => 'parmis_custom_interval',
			);
			return $schedules;
		});
		
		$timestamp = wp_next_scheduled('parmis_update_schedule_event');
		$schedule_status = get_option('parmis_schedule_status');
		if (empty($schedule_status)) {
			wp_clear_scheduled_hook('parmis_update_schedule_event');
			return false;
		}
		if (!$timestamp) {
			wp_schedule_event(time(), 'parmis_custom_interval', 'parmis_update_schedule_event');
		}
	}
	public function parmis_schedule_update_action_callback()
	{
		$result = Parmis_Shop_Public::sync_parts();
		$this->parmis_error_log(basename(__FILE__), __LINE__, $result);
	}
}
