<?php

/**
 * Fired during plugin deactivation
 *
 * @link       http://www.ParmisIT.com
 * @since      1.0.0
 *
 * @package    Parmis_Shop
 * @subpackage Parmis_Shop/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Parmis_Shop
 * @subpackage Parmis_Shop/includes
 * @author     Hassan Azizi <azizi55@ymail.com>
 * @author     kian babai <kian.babai.09@gmail.com>
 */
class Parmis_Shop_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
