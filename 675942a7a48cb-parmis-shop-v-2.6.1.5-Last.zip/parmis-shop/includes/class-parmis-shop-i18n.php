<?php

/**
 * Define the internationalization functionality
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       http://www.ParmisIT.com
 * @since      1.0.0
 *
 * @package    Parmis_Shop
 * @subpackage Parmis_Shop/includes
 */

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      1.0.0
 * @package    Parmis_Shop
 * @subpackage Parmis_Shop/includes
 * @author     Hassan Azizi <azizi55@ymail.com>
 * @author     kian babai <kian.babai.09@gmail.com>
 */
class Parmis_Shop_i18n {


	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'parmis-shop',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}



}
