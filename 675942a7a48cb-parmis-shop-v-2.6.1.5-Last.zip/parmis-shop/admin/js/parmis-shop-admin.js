(function ($) {
    'use strict';

    /**
     * All of the code for your admin-facing JavaScript source
     * should reside in this file.
     *
     * Note: It has been assumed you will write jQuery code here, so the
     * $ function reference has been prepared for usage within the scope
     * of this function.
     *
     * This enables you to define handlers, for when the DOM is ready:
     *
     * $(function() {
     *
     * });
     *
     * When the window is loaded:
     *
     * $( window ).load(function() {
     *
     * });
     *
     * ...and/or other possibilities.
     *
     * Ideally, it is not considered best practise to attach more than a
     * single DOM-ready or window-load handler for a particular page.
     * Although scripts in the WordPress core, Plugins and Themes may be
     * practising this, we should strive to set a better example in our own work.
     */
    const btn_update_order = document.getElementById('star-update-missing-orders');
    const range_update_order = document.getElementById('star-update-missing-orders-range');
    if (btn_update_order !== null) {
        btn_update_order.addEventListener('click', function () {
            document.body.style = "transition:150ms ease;opacity:.5;";
            let range = range_update_order.value;
            $.ajax({
                url: parmis_shop_admin_object.url,
                type: 'POST',
                data: {
                    action: 'parmis_shop_order_report_update',
                    nonce: parmis_shop_admin_object.nonce,
                    range: parseInt(range)
                },
                success: function (resp) {
                    if (resp.success) {
                        document.body.style.opacity = "1";
                        setTimeout(() => {
                            switch (resp.data) {
                                case 'diff':
                                    alert('به روزرسانی با موفقیت انجام شد');
                                    break;
                                case 'nodiff':
                                    alert('مغایرتی در دیتابیس یافت نشد');
                                    break;
                                default:
                                    break;
                            }
                        }, 100);
                    }
                },
                error: function (req, err) {
                    return false;
                }
            });
        });
    }
})(jQuery);


const pageInput = document.getElementById('parmis-start-report-pagination');

pageInput.addEventListener('keypress', function (event) {
    if (event.key === 'Enter') {
        event.preventDefault();
        let page = parseInt(pageInput.value);
        if (page > 0) {
            let url = new URL(window.location.href);
            url.searchParams.set('p', page); // Set the 'paged' query parameter
            window.location.href = url.toString();
        }
    }
});