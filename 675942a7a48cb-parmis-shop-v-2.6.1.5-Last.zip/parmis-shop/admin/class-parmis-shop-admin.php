<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       http://www.ParmisIT.com
 * @since      1.0.0
 *
 * @package    Parmis_Shop
 * @subpackage Parmis_Shop/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Parmis_Shop
 * @subpackage Parmis_Shop/admin
 * @author     Hassan Azizi <azizi55@ymail.com>
 * @author     kian babai <kian.babai.09@gmail.com>
 */
class Parmis_Shop_Admin
{

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct($plugin_name, $version)
	{

		$this->plugin_name = $plugin_name;
		$this->version = $version;
		add_action('admin_menu', array($this, 'addPluginAdminMenu'), 9);
		add_action('admin_init', array($this, 'registerAndBuildFields'));
	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles()
	{

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Parmis_Shop_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Parmis_Shop_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/parmis-shop-admin.css', array(), $this->version, 'all');
	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts()
	{

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Parmis_Shop_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Parmis_Shop_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/parmis-shop-admin.js', array('jquery'), $this->version, true);
		wp_localize_script($this->plugin_name, "parmis_shop_admin_object", [
			'url'	=>	admin_url('admin-ajax.php'),
			'nonce'	=>	wp_create_nonce('parmis_shop_admin_object_nonce')
		]);
	}
	public function addPluginAdminMenu()
	{
		//add_menu_page( $page_title, $menu_title, $capability, $menu_slug, $function, $icon_url, $position );
		add_menu_page($this->plugin_name, 'فروشگاه پارمیس', 'administrator', 'home', array($this, 'displayPluginAdminSettings'), 'dashicons-chart-area', 26);

		//add_submenu_page( '$parent_slug, $page_title, $menu_title, $capability, $menu_slug, $function );
		add_submenu_page('home', 'گزارشات ارسال', 'گزارشات ارسال', 'administrator', $this->plugin_name . '-reports', array($this, 'displayPluginReports'));
		add_submenu_page('home', 'تنظیمات', 'تنظیمات', 'administrator', $this->plugin_name . '-settings', array($this, 'displayPluginAdminSettings'));
		remove_submenu_page('home', 'home');
	}

	public function displayPluginAdminDashboard()
	{
		require_once 'partials/' . $this->plugin_name . '-admin-display.php';
	}

	public function displayPluginAdminSettings()
	{
		// set this var to be used in the settings-display view
		$active_tab = isset($_GET['tab']) ? $_GET['tab'] : 'general';
		if (isset($_GET['error_message'])) {
			add_action('admin_notices', array($this, 'settingsParmisShopMessages'));
			do_action('admin_notices', $_GET['error_message']);
		}
		require_once 'partials/' . $this->plugin_name . '-admin-settings-display.php';
	}

	public function displayPluginReports()
	{
		// set this var to be used in the settings-display view
		$active_tab = isset($_GET['tab']) ? $_GET['tab'] : 'general';
		if (isset($_GET['error_message'])) {
			add_action('admin_notices', array($this, 'settingsParmisShopMessages'));
			do_action('admin_notices', $_GET['error_message']);
		}
		require_once 'partials/' . $this->plugin_name . '-admin-reports-display.php';
	}
	public function settingsParmisShopMessages($error_message)
	{
		switch ($error_message) {
			case '1':
				$message = __('There was an error adding this setting. Please try again.  If this persists, shoot us an email.', 'my-text-domain');
				$err_code = esc_attr('parmis_shop_example_setting');
				$setting_field = 'parmis_shop_example_setting';
				break;
		}
		$type = 'error';
		add_settings_error(
			$setting_field,
			$err_code,
			$message,
			$type
		);
	}
	public function registerAndBuildFields()
	{
		/**
		 * First, we add_settings_section. This is necessary since all future settings must belong to one.
		 * Second, add_settings_field
		 * Third, register_setting
		 */
		add_settings_section(
			// ID used to identify this section and with which to register options
			'parmis_shop_general_section',
			// Title to be displayed on the administration page
			'',
			// Callback used to render the description of the section
			array($this, 'parmis_shop_display_general_account'),
			// Page on which to add this section of options
			'parmis_shop_general_settings'
		);
		unset($args);
		$args = array(
			'type'      => 'input',
			'subtype'   => 'text',
			'id'    => 'parmis_shop_example_setting',
			'name'      => 'parmis_shop_example_setting',
			'required' => 'true',
			'get_options_list' => '',
			'value_type' => 'normal',
			'wp_data' => 'option'
		);
		add_settings_field(
			'parmis_shop_example_setting',
			'Example Setting',
			array($this, 'parmis_shop_render_settings_field'),
			'parmis_shop_general_settings',
			'parmis_shop_general_section',
			$args
		);


		register_setting(
			'parmis_shop_general_settings',
			'parmis_shop_example_setting'
		);
	}
	public function parmis_shop_display_general_account()
	{
		echo '<p>These settings apply to all Plugin Name functionality.</p>';
	}
	public function parmis_shop_render_settings_field($args)
	{
		/* EXAMPLE INPUT
								'type'      => 'input',
								'subtype'   => '',
								'id'    => $this->plugin_name.'_example_setting',
								'name'      => $this->plugin_name.'_example_setting',
								'required' => 'required="required"',
								'get_option_list' => "",
									'value_type' = serialized OR normal,
			'wp_data'=>(option or post_meta),
			'post_id' =>
			*/
		if ($args['wp_data'] == 'option') {
			$wp_data_value = get_option($args['name']);
		} elseif ($args['wp_data'] == 'post_meta') {
			$wp_data_value = get_post_meta($args['post_id'], $args['name'], true);
		}

		switch ($args['type']) {

			case 'input':
				$value = ($args['value_type'] == 'serialized') ? serialize($wp_data_value) : $wp_data_value;
				if ($args['subtype'] != 'checkbox') {
					$prependStart = (isset($args['prepend_value'])) ? '<div class="input-prepend"> <span class="add-on">' . $args['prepend_value'] . '</span>' : '';
					$prependEnd = (isset($args['prepend_value'])) ? '</div>' : '';
					$step = (isset($args['step'])) ? 'step="' . $args['step'] . '"' : '';
					$min = (isset($args['min'])) ? 'min="' . $args['min'] . '"' : '';
					$max = (isset($args['max'])) ? 'max="' . $args['max'] . '"' : '';
					if (isset($args['disabled'])) {
						// hide the actual input bc if it was just a disabled input the info saved in the database would be wrong - bc it would pass empty values and wipe the actual information
						echo $prependStart . '<input type="' . $args['subtype'] . '" id="' . $args['id'] . '_disabled" ' . $step . ' ' . $max . ' ' . $min . ' name="' . $args['name'] . '_disabled" size="40" disabled value="' . esc_attr($value) . '" /><input type="hidden" id="' . $args['id'] . '" ' . $step . ' ' . $max . ' ' . $min . ' name="' . $args['name'] . '" size="40" value="' . esc_attr($value) . '" />' . $prependEnd;
					} else {
						echo $prependStart . '<input type="' . $args['subtype'] . '" id="' . $args['id'] . '" "' . $args['required'] . '" ' . $step . ' ' . $max . ' ' . $min . ' name="' . $args['name'] . '" size="40" value="' . esc_attr($value) . '" />' . $prependEnd;
					}
					/*<input required="required" '.$disabled.' type="number" step="any" id="'.$this->plugin_name.'_cost2" name="'.$this->plugin_name.'_cost2" value="' . esc_attr( $cost ) . '" size="25" /><input type="hidden" id="'.$this->plugin_name.'_cost" step="any" name="'.$this->plugin_name.'_cost" value="' . esc_attr( $cost ) . '" />*/
				} else {
					$checked = ($value) ? 'checked' : '';
					echo '<input type="' . $args['subtype'] . '" id="' . $args['id'] . '" "' . $args['required'] . '" name="' . $args['name'] . '" size="40" value="1" ' . $checked . ' />';
				}
				break;
			default:
				# code...
				break;
		}
	}
	public static function parmis_shop_order_report_update_callback()
	{
		if (!wp_verify_nonce($_POST['nonce'], 'parmis_shop_admin_object_nonce')) {
			wp_die();
		}
		global $table_prefix;
		global $wpdb;
		$args = [
			'limit' => -1,
			'orderby' => 'date',
			'order' => 'DESC',
			'return' => 'ids',
			'status' => array('processing', 'completed')
		];
		$range = (int) sanitize_text_field($_POST['range']);
		if ($range > 0) {
			$args['date_query'] = [
				'after' => date('Y-m-d', strtotime(($range * -1) . ' days')),
				'before' => date('Y-m-d'),
				'inclusive' => true,
			];
		}
		$query = new WC_Order_Query($args);
		$orders = $query->get_orders();
		$star_ids = $wpdb->get_col("SELECT order_id FROM " . $table_prefix . "star_send_log");
		$diff = array_diff($orders, $star_ids);
		if (count($diff) ===  0) {
			return wp_send_json_success('nodiff');
			return false;
		}
		foreach ($diff as $id) {
			$order = wc_get_order($id);
			Parmis_Shop_Public::add_order($order);
		}
		return wp_send_json_success('diff');
		wp_die();
	}
}
