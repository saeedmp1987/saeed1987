<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       plugin_name.com/team
 * @since      1.0.0
 *
 * @package    PluginName
 * @subpackage PluginName/admin/partials
 */
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div class="wrap">
	<h1>تنظیمات فروشگاه پارمیس</h1>
	<h4>
		<?php
		if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['delete_payment_key']) && $_POST["formType"] == "delete" && isset($_POST["paymentKey"])) {
			$result =  Parmis_Shop_Public::delete_payment_key($_POST["paymentKey"]);
		}

		if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["settings"])) {
			$result = Parmis_Shop_Public::save_settings(
				$_POST["accountkey"],
				$_POST["parmisUsername"],
				$_POST["password"],
				$_POST["customerUsername"],
				$_POST["customerPassword"],
				$_POST["station"],
				$_POST["paymentMethodKey"],
				$_POST["accountId"],
				$_POST['counterParty'],
				$_POST['baseUrl'],
				$_POST['customerAsCounterparty'],
				$_POST['updateQuantityFromStar'],
				$_POST['updatePricesFromStar'],
				$_POST['isToman'],
				$_POST['debugMode'],
				$_POST['paymentCriteriaApi'],
				$_POST['order_type_submit_parmis'],
				$_POST['enable_update_cronjob'],
				$_POST['interval_update_cronjob']
			);
			echo '<div class="updated notice"><p>' . $result . '</p></div>';
		}

		$settings = Parmis_Shop_Public::get_settings();

		if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["update"])) {
			$result =  Parmis_Shop_Public::sync_parts();
			echo '<div class="updated notice"><p>' . $result . '</p></div>';
		}
		?>
	</h4>
	<form method="POST" action="">
		<table class="form-table" role="presentation">
			<tbody>
				<tr>
					<th scope="row"><label for="baseUrl">آدرس پایه وب سرویس</label></th>
					<td><input dir="ltr" name="baseUrl" type="text" id="baseUrl" value="<?php echo $settings->parmis_shop_base_url; ?>" class="regular-text">
						<p class="description">نشانی اتصال به سرویس پارمیس استار</p>
					</td>
				</tr>

				<tr>
					<th scope="row"><label for="accountkey">حساب کاربری</label></th>
					<td><input dir="ltr" name="accountkey" type="text" id="accountkey" value="<?php echo $settings->parmis_shop_account_key; ?>" class="regular-text">
						<p class="description">حساب کاربری را از پشتیبانی پارمیس دریافت کنید</p>
					</td>
				</tr>

				<tr>
					<th scope="row"><label for="parmisUsername">نام کاربری</label></th>
					<td><input dir="ltr" name="parmisUsername" type="text" id="parmisUsername" value="<?php echo $settings->parmis_shop_username; ?>" class="regular-text">
						<p class="description">نام کاربری برای ارتباط با سرویس استار</p>
					</td>
				</tr>

				<tr>
					<th scope="row"><label for="password">رمز عبور</label></th>
					<td><input dir="ltr" name="password" type="text" id="password" value="<?php echo $settings->parmis_shop_password; ?>" class="regular-text">
						<p class="description">رمز عبور برای ارتباط با سرویس استار</p>
					</td>
				</tr>

				<tr>
					<th scope="row"><label for="counterParty">کد مشتری پیش فرض</label></th>
					<td><input dir="ltr" name="counterParty" type="text" id="counterParty" value="<?php echo $settings->parmis_shop_counterparty; ?>" class="regular-text">
						<p class="description">در صورتی که گزینه "ثبت فاکتور به نام کاربر ووکامرس" انتخاب نشده باشد، فاکتور ها در استار به نام این مشتری ثبت می شوند</p>
					</td>
				</tr>

				<tr>
					<th scope="row"><label>وضعیت اتصال</label></th>
					<td>
						<?php
						$ApiStatus = Parmis_Shop_Public::ParmisApiStatus();
						if ($ApiStatus) :
						?>
							<span style="color:green">متصل</span>
						<?php else : ?>
							<span style="color:red">عدم اتصال</span>
						<?php endif; ?>
					</td>
				</tr>

				<tr>
					<th><label for="accountkey">درگاه های تعریف شده</label></th>
					<td>
						<hr />
					<td>
				</tr>

				<?php foreach ($settings->parmis_shop_payment_keys as $payment) { ?>
					<tr>
						<th scope="row"><label>کلید درگاه</label></th>
						<td><input dir="ltr" name="paymentMethodKey[]" type="text" value="<?php echo $payment->payment_key; ?>" class="regular-text">
					</tr>

					<tr>
						<th scope="row"><label>کد حساب بانکی</label></th>
						<td>
							<input dir="ltr" name="accountId[]" type="text" value="<?php echo $payment->payment_value; ?>" class="regular-text">
							<form method="POST" action="">
								<p class="submit">
									<input type="submit" name="delete_payment_key" class="button button-danger" value="حذف حساب بانکی و درگاه">
									<input type="hidden" name="formType" value="delete" />
									<input type="hidden" name="paymentKey" value="parmis_shop_payment_key_<?php echo $payment->payment_key; ?>">
								</p>
							</form>
							<hr />
						</td>
					</tr>
				<?php } ?>

				<tr>
					<th scope="row"><label for="accountkey">افزودن حساب بانکی و درگاه</label></th>
					<td>
						<hr />
					<td>
				</tr>

				<tr>
					<th scope="row"><label for="accountkey">کلید درگاه</label></th>
					<td><input dir="ltr" name="paymentMethodKey[]" type="text" class="regular-text">
						<p class="description">کلید درگاه ووکامرس</p>
					</td>
				</tr>

				<tr>
					<th scope="row"><label>کد حساب بانکی استار</label></th>
					<td><input dir="ltr" name="accountId[]" type="text" class="regular-text">
						<p class="description">کد حساب بانکی معادل درگاه ووکامرس که در استار تعریف شده است</p>
					</td>
				</tr>

				<tr>
					<th><label>درگاه های موجود در سیستم</label></th>
					<td>
						<table class="wp-list-table widefat fixed striped table-view-list" style="width: 300px;">
							<thead>
								<tr>
									<th>نام درگاه</th>
									<th>کلید درگاه</th>
								</tr>
							</thead>
							<tbody id="the-list">
								<?php
								$gateways = WC()->payment_gateways->get_available_payment_gateways();
								$enabled_gateways = [];
								if ($gateways) {
									foreach ($gateways as $gateway) {
										if ($gateway->enabled == 'yes') {
											$enabled_gateways[] = $gateway;
										}
									}
								}
								foreach ($enabled_gateways as $gw) : ?>
									<tr>
										<td>
											<span><?php echo $gw->method_title; ?></span>
										</td>
										<td>
											<span><?php echo $gw->id; ?></span>
										</td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="">نوع ثبت سفارشات در پارمیس</label>
					</th>
					<td>
						<?php
						$order_submit_type = [
							'بدون وضعیت',
							'سفارش فروش',
							'فاکتور فروش',
							'پیش فاکتور فروش'
						];
						?>
						<select name="order_type_submit_parmis" id="order_type_submit_parmis">
							<?php
							$h = 1;
							foreach ($order_submit_type as $type) {
								printf('<option value="%s" %s>%s</option>', $h, ($settings->parmis_shop_order_submission_type === $h) ? 'selected' : '', $type);
								$h++;
							}
							?>
						</select>
					</td>
				</tr>
				<tr>
					<th scope="row"><label>تنظیمات عمومی</label></th>
					<td>
						<input name="customerAsCounterparty" type="checkbox" id="customerAsCounterparty" value="customerAsCounterparty" <?php if ($settings->parmis_shop_save_customer) {
																																			echo 'checked';
																																		} ?>>
						<label for="customerAsCounterparty">ثبت فاکتور به نام کاربر ووکامرس</label>
						</br>
						</br>
						<input name="updateQuantityFromStar" type="checkbox" id="updateQuantityFromStar" value="updateQuantityFromStar" <?php if ($settings->parmis_shop_update_quantities) {
																																			echo 'checked';
																																		} ?>>
						<label for="updateQuantityFromStar">تغییر موجودی کالا بر اساس موجودی استار</label>
						</br>
						</br>
						<input name="updatePricesFromStar" type="checkbox" id="updatePricesFromStar" value="updatePricesFromStar" <?php if ($settings->parmis_shop_update_prices) {
																																		echo 'checked';
																																	} ?>>
						<label for="updatePricesFromStar">تغییر قیمت کالا بر اساس قیمت تعریف شده در استار</label>
						</br>
						</br>
						<input name="isToman" type="checkbox" id="isToman" value="isToman" <?php if ($settings->parmis_shop_is_toman) {
																								echo 'checked';
																							} ?>>
						<label for="isToman">استفاده از واحد پولی تومان</label>
						</br>
						</br>
						<input name="debugMode" type="checkbox" id="debugMode" value="debugMode" <?php if ($settings->parmis_shop_debug_mode) {
																										echo 'checked';
																									} ?>>
						<label for="debugMode" style="color: red;">Debug Mode</label>
						</br>
						</br>
						<input type="checkbox" name="paymentCriteriaApi" id="paymentCriteriaApi" value="paymentCriteriaApi" <?php echo ($settings->parmis_shop_payment_criteria_api) ? 'checked' : ''; ?>>
						<label for="paymentCriteriaApi">غیر فعالسازی پرداخت در صفحه تسویه حساب در صورت عدم اتصال به سامانه پارمیس</label>
					</td>
				</tr>
				<tr>
					<th scope="row"><label>به روز رسانی خودکار</label></th>
					<td>

						<input type="checkbox" name="enable_update_cronjob" id="enable_update_cronjob" value="enable_update_cronjob" <?php echo ($settings->parmis_schedule_status) ? 'checked' : ''; ?>>
						<label for="enable_update_cronjob">فعالسازی به روز رسانی خودکار</label>
						</br>
						</br>
						<?php if ($settings->parmis_schedule_status) : ?>
							<label for="interval_update_cronjob">انتخاب بازه زمانی به روز رسانی : هر</label>
							<select name="interval_update_cronjob" id="interval_update_cronjob">
								<?php
								$intervals = [
									'غیر فعال'	=>	0,
									'15 دقیقه'	=>	15,
									'30 دقیقه'	=>	30,
									'45 دقیقه'	=>	45,
									'یک ساعت'	=>	60,
									'سه ساعت'	=>	180,
									'شش ساعت'	=>	360,
									'دوازده ساعت'	=>	720,
									'یک روز'	=>	1440,
									// 'دو روز'	=>	2880,
									// 'چهار روز'	=>	5760,
									// 'یک هفته'	=>	10080,
									// 'دو هفته'	=>	20160,
									// 'یک ماه'	=>	40320
								];
								foreach ($intervals as $label => $value) {
									printf('<option value="%s" %s>%s</option>', $value, ($settings->parmis_schedule_interval == $value) ? 'selected' : '', $label);
								}
								?>
							</select>
						<?php endif; ?>
					</td>
				</tr>
			</tbody>
		</table>

		<div style="display: flex;">
			<p class="submit">
				<input type="submit" name="settings" class="button button-primary" value="ذخیرهٔ تغییرات">
			</p>

			<p class="submit" style="margin-right: 5px;">
				<input type="submit" name="update" class="button button-primary" value="بروزرسانی کالاها">
			</p>
		</div>
	</form>
</div>