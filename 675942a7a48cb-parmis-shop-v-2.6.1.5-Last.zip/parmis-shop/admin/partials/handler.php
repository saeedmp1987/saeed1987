<?php
    require('../../../../../wp-load.php');

    global $wpdb;
    global $table_prefix;
		
 	if($_SERVER["REQUEST_METHOD"]==="POST")
 	{
 	    if (!empty($_POST["order"])) {
 	        $orderId = $_POST["order"];
 		    $order = wc_get_order($orderId);
 		    echo json_encode(Parmis_Shop_Public::add_order($order));
 	    }
 	}
?>