<?php

require_once('calendar-helper.php');

global $wpdb;

global $table_prefix;



$pageSize = 20;

$currentPage = 1;

$searchTerm = "";

$type = 0;



if ($_SERVER["REQUEST_METHOD"] === "GET") {

	if (!empty($_GET["p"])) {

		$currentPage = (int) sanitize_text_field($_GET["p"]);
	}



	if (!empty($_GET["s"])) {

		$searchTerm = sanitize_text_field($_GET["s"]);
	}



	if (!empty($_GET["t"])) {

		$type = (int) sanitize_text_field($_GET["t"]);
	}
}



$query = "SELECT * FROM " . $table_prefix . "star_send_log";



$query = $query . " WHERE is_sent IN (";

if ($type === 0) {

	$query = $query . "0, 1";
} else if ($type === 1) {

	$query = $query . "1";
} else {

	$query = $query . "0";
}

$query = $query . ")";

$query = $query . ' ORDER BY order_date DESC';

$is_Search = false;

if (!empty($searchTerm) && strlen($searchTerm) > 0) {

	$query = $query . (" AND order_id LIKE '%" . $searchTerm . "%'");

	$is_Search = true;
} else {

	$query = $query . ' LIMIT ' . $pageSize . ' OFFSET ' . ($currentPage - 1) * $pageSize;
}



$res = $wpdb->get_results($query);



$allCount = ($is_Search) ? $wpdb->num_rows : $wpdb->get_var("SELECT Count(*) FROM " . $table_prefix . "star_send_log");

$sentCount = $wpdb->get_var("SELECT Count(*) FROM " . $table_prefix . "star_send_log WHERE is_sent = 1");

$notSentCount = $wpdb->get_var("SELECT Count(*) FROM " . $table_prefix . "star_send_log WHERE is_sent = 0");



// $totalCount = count($res);

$totalCount = $allCount;

$totalPages = ceil($totalCount / $pageSize);

if ($totalPages == 0) {

	$totalPages = 1;
}

if ($currentPage > $totalPages) {

	$currentPage = $totalPages;
}

?>

<div class="wrap">

	<h1>گزارشات ارسال فروشگاه پارمیس</h1>

	<?php

	echo '<ul class="subsubsub">';

	echo '<li class="all"><a href="admin.php?page=parmis-shop-reports">همه <span class="count">(' . $allCount . ')</span></a> |</li>';

	echo '<li class="all"><a href="admin.php?page=parmis-shop-reports&amp;t=1">ارسال شده <span class="count">(' . $sentCount . ')</span></a> |</li>';

	echo '<li class="all"><a href="admin.php?page=parmis-shop-reports&amp;t=2">ارسال نشده <span class="count">(' . $notSentCount . ')</span></a></li>';

	echo '</ul>';

	?>

	<div class="tablenav top">

		<?php

		echo '<form class="alignleft" method="get">';

		echo '<input type="hidden" name="page" value="parmis-shop-reports"/>';

		echo '<p class="search-box">';

		echo '<input type="search" id="search-input" name="s" placeholder="شماره سفارش..." value="';

		if (!empty($searchTerm) && strlen($searchTerm) > 0) {

			echo $searchTerm;
		}

		echo '">';

		echo '<input type="submit" id="search-submit" class="button" value="جستجو">';

		echo '<button type="button" id="star-update-missing-orders" class="button">به روزرسانی سفارشات</button>';

		$range = [
			'0'	=>	'بدون محدودیت زمانی',
			'7'	=>	'هفت روز گذشته',
			'30'	=>	'یک ماه گذشته'
		];
		echo '<select id="star-update-missing-orders-range">';
		foreach ($range as $key => $value) {
			printf('<option value="%1$s">%2$s</option>', $key, $value);
		}
		echo '</select>';

		echo '</p>';

		echo '</form>';



		echo '<form method="get">';

		echo '<input type="hidden" name="page" value="parmis-shop-reports"/>';

		echo '<div class="tablenav-pages">';

		echo '<span class="displaying-num">' . $totalCount . ' مورد</span>';

		if ($currentPage == 1) {

			echo '<span class="tablenav-pages-navspan button disabled" aria-hidden="true" style="margin-left:5px;">‹</span>';
		} else {

			echo '<a class="prev-page button" style="margin-left:5px;" href="' . admin_url('admin.php?page=parmis-shop-reports') . '&amp;p=' . ($currentPage - 1) . '">';

			echo '<span aria-hidden="true">‹</span>';

			echo '</a>';
		}

		echo '<span class="paging-input" style="margin-left:5px;">';

		echo '<label for="current-page-selector" class="screen-reader-text">برگهٔ فعلی</label>';

		echo '<span class="tablenav-paging-text"><input id="parmis-start-report-pagination" type="number" value="' . $currentPage . '"></span>';

		echo '<span class="tablenav-paging-text"> از <span class="total-pages">' . $totalPages . '</span></span>';

		echo '</span>';

		if ($currentPage == $totalPages) {

			echo '<span class="tablenav-pages-navspan button disabled" aria-hidden="true">›</span>';
		} else {

			echo '<a class="next-page button" href="' . admin_url('admin.php?page=parmis-shop-reports') . '&amp;p=' . ($currentPage + 1) . '">';

			echo '<span aria-hidden="true">›</span>';

			echo '</a>';
		}

		echo '</form>';

		?>

	</div>

</div>

<table class="wp-list-table widefat fixed striped table-view-list posts">

	<thead>

		<tr>

			<th scope="col" class="manage-column" style="width: 50px !important;">ردیف</th>

			<th scope="col" class="manage-column" style="width: 250px !important;">شماره سفارش</th>

			<th scope="col" class="manage-column" style="width: 200px !important;">تاریخ سفارش</th>

			<th scope="col" class="manage-column" style="width: 200px !important;">تاریخ ارسال</th>

			<th scope="col" class="manage-column" style="text-align: center;width: 100px !important;">سریال استار</th>

			<th scope="col" class="manage-column" style="text-align: center;width: 100px !important;">وضعیت</th>

			<th scope="col" class="manage-column" style="text-align: center;">پیغام</th>

			<th scope="col" class="manage-column" style="width: 120px !important; text-align: center;">عملیات</th>

		</tr>

	</thead>



	<tbody id="the-list">

		<?php

		$startIndex = (($currentPage - 1) * $pageSize);

		foreach ($res as $row) {

			$order = wc_get_order($row->order_id);

			$startIndex = $startIndex + 1;

			echo '<tr>';

			echo '<td class="order_number column-primary">';

			echo $startIndex;

			echo '</td>';

			echo '<td class="column-primary">';

			if ($order) {

				echo '<a href="' . admin_url('/') . 'post.php?post=' . $row->order_id . '&amp;action=edit" class="order-view">';

				echo '<strong>#' . $row->order_id . ' ' . $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() . '</strong></a>';
			} else {

				echo '<strong>#' . $row->order_id . '</strong>';
			}

			echo '</td>';

			echo '<td style="text-align: right;">';

			echo '<span>';

			if ($row->order_date) {

				echo CalendarHelper::jdate($row->order_date, true, false);
			}

			echo '</span>';

			echo '</td>';

			echo '<td style="text-align: right;">';

			echo '<span>';

			if ($row->send_date) {

				echo CalendarHelper::jdate($row->send_date, true, false);
			}

			echo '</span>';

			echo '</td>';

			echo '<td style="text-align: center;">';

			echo '<span id="serial-' . $row->order_id . '">' . $row->star_serial . '</span>';

			echo '</td>';

			echo '<td style="text-align: center;">';

			echo '<mark id="mark-' . $row->order_id . '" class="parmis-status-label ';

			if ($row->is_sent) {

				echo 'parmis-status-ok';
			} else {

				echo 'parmis-status-notok';
			}

			echo '">';

			echo '<span id="status-' . $row->order_id . '" style="font-weight: 600;">';

			if ($row->is_sent) {

				echo 'ارسال شده';
			} else {

				echo 'ارسال نشده';
			}

			echo '</span>';

			echo '</mark>';

			echo '</td>';

			echo '<td style="text-align: center;">';

			echo '<span id="result-' . $row->order_id . '">';

			echo ($row->fail_message . ' ' . $row->fail_detail_message);

			echo '</span>';

			echo '</td>';

			echo '<td style="text-align: center;">';

			if (!$row->is_sent) {

				echo '<div>';

				echo ('<button id="btn-' . $row->order_id . '" class="parmis-shop-send-button" type="submit" onclick="send(' . $row->order_id . ')">ارسال مجدد</button>');



				echo '</div>';
			}

			echo '</td>';

			echo '</tr>';
		}

		?>

		<script>
			async function send(orderId) {



				var btn = document.getElementById("btn-" + orderId);

				var serial = document.getElementById("serial-" + orderId);

				var mark = document.getElementById("mark-" + orderId);

				var status = document.getElementById("status-" + orderId);

				var result = document.getElementById("result-" + orderId);



				btn.disabled = true;

				btn.innerHTML = "در حال ارسال...";

				btn.style.backgroundColor = "#EEEEEE";

				btn.style.color = "#000";



				await jQuery.post('<?php echo (plugin_dir_url(__FILE__) . 'handler.php'); ?>', {

					order: orderId

				}, function(data) {

					var res = JSON.parse(data);

					serial.innerHTML = res.star_serial;

					if (res.is_sent == "1") {

						mark.classList.remove("parmis-status-notok");

						mark.classList.add("parmis-status-ok");

						mark.innerHTML = "ارسال شده";

						btn.style.display = "none";

					} else {

						btn.disabled = false;

						btn.innerHTML = "ارسال مجدد";

						btn.style.backgroundColor = "#5b841b";

						btn.style.color = "#fff";

					}



					var message = "";

					if (res.fail_message) message = message + res.fail_message;

					if (res.fail_detail_message) message = message + " " + res.fail_detail_message;

					result.innerHTML = message;

				});

			}
		</script>

	</tbody>

</table>

</div>